from django.apps import AppConfig


class HandwrittenboardConfig(AppConfig):
    name = 'handwrittenBoard'
